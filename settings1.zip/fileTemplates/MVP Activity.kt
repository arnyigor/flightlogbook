#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")

import android.os.Bundle

class ${NAME} : BaseMvpActivity<${ContractName}.View, ${PresenterName}>(), ${ContractName}.View {
    override fun initPresenter(): ${PresenterName} {
        return ${PresenterName}()
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.${layout})
    }
}
