#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")
class ${NAME} private constructor() {
    private object Holder {
        val INSTANCE = ${NAME}()
    }
    companion object {
        val instance: ${NAME} by lazy { Holder.INSTANCE }
    }
}