#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

class ${NAME} : BaseMvpFragment<${ContractName}.View, ${PresenterName}>(), ${ContractName}.View {

    override fun initPresenter(): ${PresenterName} {
        return ${PresenterName}()
    }

    companion object {
        fun newInstance(id: Long?): ${NAME} {
            val fragment = ${NAME}()
            val args = Bundle()
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.${layout}, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
    }
}
